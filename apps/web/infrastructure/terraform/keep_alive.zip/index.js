// Keep-alive Lambda function
exports.handler = async (event) => {
  const serviceUrl = process.env.SERVICE_URL || 'https://cribnosh.co.uk';
  const concurrency = parseInt(process.env.KEEP_ALIVE_CONCURRENCY || '10');
  
  console.log('Starting keep-alive process', { serviceUrl, concurrency });
  
  const endpoints = [
    `${serviceUrl}/api/keep-alive`,
    `${serviceUrl}/api/health/fast`,
    `${serviceUrl}/api/health`,
    `${serviceUrl}/`
  ];
  
  const pingEndpoint = async (url) => {
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'User-Agent': 'KeepAlive-Lambda/1.0',
          'X-Keep-Alive': 'true'
        }
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      console.log(`Successfully pinged ${url}`);
    } catch (error) {
      console.warn(`Failed to ping ${url}:`, error);
    }
  };
  
  const promises = Array.from({ length: concurrency }, () => 
    Promise.all(endpoints.map(pingEndpoint))
  );
  
  const results = await Promise.allSettled(promises);
  const successful = results.filter(r => r.status === 'fulfilled').length;
  
  console.log(`Keep-alive completed: ${successful}/${results.length} successful`);
  
  return {
    statusCode: 200,
    body: JSON.stringify({
      success: true,
      message: 'Keep-alive process completed',
      stats: { successful, total: results.length }
    })
  };
};
